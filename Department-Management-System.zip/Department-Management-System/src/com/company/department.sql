-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 17, 2021 at 10:21 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `department`
--

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `Faculty ID` varchar(6) DEFAULT NULL,
  `Faculty Name` varchar(30) DEFAULT NULL,
  `Email ID` varchar(40) DEFAULT NULL,
  `Semester` varchar(3) DEFAULT NULL,
  `Experience` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`Faculty ID`, `Faculty Name`, `Email ID`, `Semester`, `Experience`) VALUES
('1001', 'Abdul Jabbar', 'ajabbar@gmail.com', '1st', '5 years'),
('1021', 'Sajjad Ali', 'alisajad@gmail.com', '2nd', ' 3 year');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `Roll no` varchar(8) DEFAULT NULL,
  `Student Name` varchar(30) DEFAULT NULL,
  `Email ID` varchar(50) DEFAULT NULL,
  `Section` varchar(4) DEFAULT NULL,
  `Sem/Year` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`Roll no`, `Student Name`, `Email ID`, `Section`, `Sem/Year`) VALUES
('kjd', 'juhfej', 'jhefjh', '1st', 'kje');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `Subject Code` varchar(10) DEFAULT NULL,
  `Subject Name` varchar(20) DEFAULT NULL,
  `Sem/Year` varchar(10) DEFAULT NULL,
  `Subject Type` varchar(10) DEFAULT NULL,
  `Theory Marks` varchar(10) DEFAULT NULL,
  `Practical Marks` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`Subject Code`, `Subject Name`, `Sem/Year`, `Subject Type`, `Theory Marks`, `Practical Marks`) VALUES
('mth-109', 'laag', '2nd', '3 c.h', '100', 'NO');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
