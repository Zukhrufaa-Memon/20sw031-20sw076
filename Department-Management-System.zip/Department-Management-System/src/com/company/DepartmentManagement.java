package   com.company;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

public class DepartmentManagement {
    // public static  JTable table = new JTable();
    public static   DefaultTableModel model = new DefaultTableModel();


    DepartmentManagement() {
        JFrame f=new JFrame("Department Management System");
        JFrame f1 = new JFrame("Department Management System");
        f.setSize(1000,700);
        ImageIcon img=new ImageIcon("C:\\Users\\Zukhrufa\\IdeaProjects\\untitled\\src\\com\\company\\logo1.png");
        JLabel lbl=new JLabel(img);
        Border border=BorderFactory.createRaisedBevelBorder();

        String s[]={"1st Semester","2nd Semester","3rd Semester","4th Semester","5th Semester","6th Semester","7th Semester","8th Semester"};
        JComboBox cb=new JComboBox(s);//for faculty
        JComboBox cb1=new JComboBox(s);//for student
        JComboBox cb2=new JComboBox(s);//for subjects
        cb.setBounds(450,100,150,30);
        cb1.setBounds(450,100,150,30);
        cb2.setBounds(450,100,150,30);
        JPanel p=new JPanel();//frame1
        JPanel p1=new JPanel();//frame1
        JPanel pabout=new JPanel();
        JPanel panel = new JPanel();//frame2 side panel
        JPanel panel1 = new JPanel();//center panel frame2
        JPanel p3=new JPanel();//frame1
        JPanel panel3=new JPanel();//frame2 header panel
        JPanel panel2=new JPanel();//faculty center panel
        JPanel panel4=new JPanel();//students center panel
        JPanel panel5=new JPanel();//subjects center panel
        JPanel panel6=new JPanel();//attendance center panel
        JButton btn51=new JButton("Sign In");

        ///////////////bg setup///////////////////////

        pabout.setVisible(false);
        p1.setLayout(null);
        p.setBounds(1,1,250,700);///side panel frame1
        p.setBackground(new Color(11,11,46));
        //  p.setBackground(new Color(70,50,95));
        p.setLayout(null);
        lbl.setBounds(25,30,200,130);
        p1.setBounds(201,1,800,700);
        p1.setBackground(Color.white);
        JLabel lbl2=new JLabel(new ImageIcon("C:\\Users\\Zukhrufa\\IdeaProjects\\untitled\\src\\com\\company\\images12.jpg"));//background
        lbl2.setBounds(1,1,800,700);
        p1.add(lbl2);
        JPanel p2=new JPanel();//header frame1

        p2.setBounds(1,1,900,80);
        p2.setBackground(new Color(11,11,46,230));
        p2.setLayout(null);
        JLabel lbl1=new JLabel("Welcome To Software Department !");
        lbl1.setForeground(Color.white);
        lbl1.setBounds(230,2,450,60);
        lbl1.setFont(new Font("Arial",Font.BOLD,24));
        p2.add(lbl1);
        lbl2.add(p2);

        ////////////////////sidepanel buttons//////////////////
        JButton btn=new JButton("Admin ");
        btn.setFont(new Font("Arial",Font.BOLD,20));
        btn.setForeground(Color.white);
        btn.setBackground(new Color(11,11,46));
        btn.setBounds(1,210,250,50);
        btn.setBorderPainted(false);
        btn.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {}
            @Override
            public void mousePressed(MouseEvent e) {}
            @Override
            public void mouseReleased(MouseEvent e) {}
            @Override
            public void mouseEntered(MouseEvent e) {
                //btn.setBackground(new Color(116,66,200));}
                btn.setBackground(new Color(27,27,132));}
            @Override
            public void mouseExited(MouseEvent e) {
                btn.setBackground(new Color(11,11,46));}});

        JButton btn1=new JButton(" Student ");
        btn1.setFont(new Font("Arial",Font.BOLD,20));
        btn1.setForeground(Color.white);
        btn1.setBackground(new Color(11,11,46));
        btn1.setBounds(1,275,250,50);
        btn1.setBorderPainted(false);
        btn1.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {}
            @Override
            public void mousePressed(MouseEvent e) {}
            @Override
            public void mouseReleased(MouseEvent e) {}
            @Override
            public void mouseEntered(MouseEvent e) {
                btn1.setBackground(new Color(27,27,132));}
            @Override
            public void mouseExited(MouseEvent e) {
                btn1.setBackground(new Color(11,11,46));}});

        JButton btn2=new JButton("About Us");
        btn2.setFont(new Font("Arial",Font.BOLD,20));
        btn2.setForeground(Color.white);
        btn2.setBackground(new Color(11,11,46));
        btn2.setBounds(1,340,250,50);
        btn2.setBorderPainted(false);
        btn2.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {}
            @Override
            public void mousePressed(MouseEvent e) {}
            @Override
            public void mouseReleased(MouseEvent e) {}
            @Override
            public void mouseEntered(MouseEvent e) {
                btn2.setBackground(new Color(27,27,132));}
            @Override
            public void mouseExited(MouseEvent e) {
                btn2.setBackground(new Color(11,11,46));}});
        btn2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                pabout.setLayout(null);
                pabout.setVisible(true);
                p1.setVisible(false);
                p.setBounds(1,1,250,700);///side panel frame1
                p.setBackground(new Color(11,11,46));
                //  p.setBackground(new Color(70,50,95));
                p.setLayout(null);
                lbl.setBounds(25,30,200,130);
                pabout.setBounds(201,1,800,700);
                pabout.setBackground(Color.white);
                p2.setBounds(1,1,900,80);
                p2.setBackground(new Color(11,11,46,230));
                p2.setLayout(null);
                JLabel lbl1=new JLabel("Welcome To Software Department !");
                lbl1.setForeground(Color.white);
                lbl1.setBounds(230,2,450,60);
                lbl1.setFont(new Font("Arial",Font.BOLD,24));
                p2.add(lbl1);
                pabout.add(p2);
                f.add(pabout);
                /////pic////
                JLabel lblp=new JLabel(new ImageIcon("C:\\Users\\Zukhrufa\\IdeaProjects\\untitled\\src\\com\\company\\chairman1.jpg"));//background
                lblp.setBounds(90,150,200,300);
                pabout.add(lblp);
                pabout.setLayout(null);
                JLabel cmsg=new JLabel("<html>Dr. Naeem Mahoto<BR>" +
                        " Software Engineering Department used to conduct its<BR> programs in conjunction with the Department of Computer<BR> Systems Engineering untill 2009, after which the Department<BR> of Software Engineering got its own building.<BR> The department offers Bachelors of Engineering (B.E),<BR> Masters of Engineering (M.E) and Doctorate (Ph.D.)<BR> degrees in Software Engineering. Our graduates<BR> are already serving in the reputable public and private sector<BR> Software organizations both locally and internationally.<BR>" +
                        "The department provides a congenial environment for<BR> carrying out edge-cutting research and experimental <BR>work with modern state-of-the-art laboratories in<BR> collaboration with our top-notch faculty members. Our<BR> faculty is highly qualified and always ready to guide the students<BR> in any academic related problem, where as the<BR> courteous administrative staff is always attentive to<BR> address the students' problems.<BR>" +
                        "Please explore the department of Software Engineering,<BR> I am sure you will love to be a part of this department.<BR>" +
                        "Dr. Naeem Ahmed Mahoto<BR>" +
                        "Chairman  (@taken from sw website)<html>");
                cmsg.setBounds(350,1,700,700);
                cmsg.setForeground(Color.black);
                cmsg.setFont(new Font("Arial",Font.PLAIN,14));
                pabout.add(cmsg);
                JLabel contact=new JLabel("Contact");
                contact.setFont(new Font("Arial",Font.BOLD,20));
                contact.setForeground(Color.black);
                contact.setBounds(150,530,100,100);
                pabout.add(contact);
                JLabel email=new JLabel("Email : chairman.sw@admin.muet.edu.pk");
                email.setFont(new Font("Arial",Font.PLAIN,15));
                email.setForeground(Color.black);
                email.setBounds(300,530,300,100);
                pabout.add(email);
                JLabel phone=new JLabel("Phone : +92-22-2772277");
                phone.setFont(new Font("Arial",Font.PLAIN,15));
                phone.setForeground(Color.black);
                phone.setBounds(300,550,300,100);
                pabout.add(phone);


            }
        });

        ///////////////////////ADMIN STUDENT LOGIN BUTTONS/////////////////////
        JButton btn3=new JButton();
        btn3.setIcon(new ImageIcon("C:\\Users\\Zukhrufa\\IdeaProjects\\untitled\\src\\com\\company\\usericon3.png"));
        btn3.setBounds(155,170,230,210);//230 for purple
        btn3.setBorder(border);
        btn3.setBorderPainted(false);

        JButton btn4=new JButton();
        btn4.setIcon(new ImageIcon("C:\\Users\\Zukhrufa\\IdeaProjects\\untitled\\src\\com\\company\\usericon4.png"));
        btn4.setBounds(490,170,230,210);//230 for purple
        btn4.setBorder(border);
        btn4.setBorderPainted(false);

        btn3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                ///////login panel//////////
                btn3.setVisible(false);
                btn4.setVisible(false);

                lbl2.add(p3);
                //  p3.setBackground(new Color(110,80,110,190));
                p3.setBackground(new Color(11,11,46,230));
                p3.setBounds(240,140,300,350);
                p3.setBorder(border);
                p3.setLayout(null);

                ImageIcon imag=new ImageIcon("C:\\Users\\Zukhrufa\\IdeaProjects\\untitled\\src\\com\\company\\user3.png");
                JLabel imaglbl=new JLabel(imag);
                imaglbl.setBounds(100,10,100,150);
                p3.add(imaglbl);
                Border border1=BorderFactory.createMatteBorder(0,0,1,0,new Color(70,50,95));//for line textbox
                JTextField name =new JTextField();
                name.setBounds(70,170,170,25);
                name.setBorder(border1);

                p3.add(name);
                JPasswordField pass=new JPasswordField();
                pass.setBounds(70,220,170,25);
                pass.setBorder(border1);
                p3.add(pass);

                JButton btn5=new JButton("Sign In");
                btn5.setForeground(Color.white);
                btn5.setBorder(border);
                btn5.setBounds(90,280,130,30);
                btn5.setBackground(new Color(27,27,132));
                p3.add(btn5);
                btn5.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        String namevalue = name.getText();
                        String passvalue = pass.getText();
                        if (namevalue.equals("admin")&&passvalue.equals("software")) {
                            f.setVisible(false);

                            //////////////////////// frame 2///////////////////////////////

                            f1.setSize(1050, 700);
                            ImageIcon imag = new ImageIcon("C:\\Users\\Zukhrufa\\IdeaProjects\\untitled\\src\\com\\company\\logo1.png");
                            JLabel lblimag = new JLabel(imag);
                            ///////////////bg setup///////////////////////

                            panel1.setLayout(null);
                            panel.setBounds(1, 1, 250, 700);///side panel frame2
                            panel.setBackground(new Color(11, 11, 46));
                            panel.setLayout(null);
                            lblimag.setBounds(25, 30, 200, 130);//sw logo bounds
                            panel.add(lblimag);
                            panel1.setBounds(201, 1, 900, 700);
                            panel1.setBackground(Color.white);
                            // JPanel p2=new JPanel();
                            f1.add(panel);
                            f1.add(panel1);
                            f1.setLayout(new BorderLayout());
                            f1.setVisible(true);
                            f1.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);


                            ////////////////////sidepanel buttons frame 2//////////////////
                            JButton btn6 = new JButton("Home         ");
                            btn6.setFont(new Font("Arial", Font.BOLD, 20));
                            btn6.setForeground(Color.white);
                            btn6.setBackground(new Color(11, 11, 46));
                            btn6.setBounds(1, 210, 250, 50);
                            btn6.setBorderPainted(false);
                            panel.add(btn6);
                            JButton addfac = new JButton("Add Faculty");
                            JButton addstu = new JButton("Add Student");
                            JButton addsub = new JButton("Add Subject");
                            btn6.addMouseListener(new MouseListener() {
                                @Override
                                public void mouseClicked(MouseEvent e) {
                                }

                                @Override
                                public void mousePressed(MouseEvent e) {
                                }

                                @Override
                                public void mouseReleased(MouseEvent e) {
                                }

                                @Override
                                public void mouseEntered(MouseEvent e) {
                                    btn6.setBackground(new Color(27, 27, 132));
                                }

                                @Override
                                public void mouseExited(MouseEvent e) {
                                    btn6.setBackground(new Color(11, 11, 46));
                                }
                            });
                            /////////////////////////////// frame 2 (dashboard)/////////////////////////////

                            panel3.setBounds(5, 1, 1000, 140);
                            panel3.setBackground(new Color(11, 11, 46, 230));
                            panel3.setLayout(null);
                            JLabel lbldash = new JLabel("  Home ");
                            panel3.add(lbldash);
                            addfac.setVisible(false);
                            addsub.setVisible(false);
                            addstu.setVisible(false);

                            lbldash.setForeground(Color.white);
                            lbldash.setBounds(70, 60, 450, 80);
                            lbldash.setFont(new Font("Arial", Font.BOLD, 28));
                            JButton btn10 = new JButton();
                            btn10.setBounds(100, 230, 150, 180);
                            btn10.setIcon(new ImageIcon("C:\\Users\\Zukhrufa\\IdeaProjects\\untitled\\src\\com\\company\\stuex.png"));
                            panel1.add(btn10);
                            btn10.setBorder(border);
                            JButton btn12 = new JButton();
                            btn12.setBounds(340, 230, 150, 180);
                            btn12.setIcon(new ImageIcon("C:\\Users\\Zukhrufa\\IdeaProjects\\untitled\\src\\com\\company\\facex2.png"));
                            panel1.add(btn12);
                            btn12.setBorder(border);
                            JButton btn13 = new JButton();
                            btn13.setBounds(560, 230, 150, 180);
                            btn13.setIcon(new ImageIcon("C:\\Users\\Zukhrufa\\IdeaProjects\\untitled\\src\\com\\company\\bookex.png"));
                            panel1.add(btn13);
                            btn13.setBorder(border);

                            //////////////////////////dashboard action listener//////////////////////////

                            btn6.addActionListener(new ActionListener() {
                                @Override
                                public void actionPerformed(ActionEvent e) {
                                    addfac.setVisible(false);
                                    addstu.setVisible(false);
                                    addsub.setVisible(false);
                                    panel2.setVisible(false);
                                    panel6.setVisible(false);

                                    panel1.setVisible(true);
                                    panel1.add(panel3);
                                    lbldash.setText("Home");
                                    lbldash.setForeground(Color.white);
                                    lbldash.setBounds(70, 60, 450, 80);
                                    lbldash.setFont(new Font("Arial", Font.BOLD, 28));
                                    JButton btn10 = new JButton();
                                    btn10.setBounds(100, 230, 150, 180);
                                    btn10.setIcon(new ImageIcon("C:\\Users\\Zukhrufa\\IdeaProjects\\untitled\\src\\com\\company\\stu.png"));
                                    panel1.add(btn10);
                                    btn10.setBorder(border);
                                    JButton btn12 = new JButton();
                                    btn12.setBounds(340, 230, 150, 180);
                                    btn12.setIcon(new ImageIcon("C:\\Users\\Zukhrufa\\IdeaProjects\\untitled\\src\\com\\company\\facex.png"));
                                    panel1.add(btn12);
                                    btn12.setBorder(border);
                                    JButton btn13 = new JButton();
                                    btn13.setBounds(560, 230, 150, 180);
                                    btn13.setIcon(new ImageIcon("C:\\Users\\Zukhrufa\\IdeaProjects\\untitled\\src\\com\\company\\sub.png"));
                                    panel1.add(btn13);
                                    btn13.setBorder(border);
                                    cb.setVisible(false);
                                }
                            });


                            JButton btn7 = new JButton("Faculty      ");
                            btn7.setFont(new Font("Arial", Font.BOLD, 20));
                            btn7.setForeground(Color.white);
                            btn7.setBackground(new Color(11, 11, 46));
                            btn7.setBounds(1, 275, 250, 50);
                            btn7.setBorderPainted(false);
                            panel.add(btn7);
                            btn7.addMouseListener(new MouseListener() {
                                @Override
                                public void mouseClicked(MouseEvent e) {
                                }

                                @Override
                                public void mousePressed(MouseEvent e) {
                                }

                                @Override
                                public void mouseReleased(MouseEvent e) {
                                }

                                @Override
                                public void mouseEntered(MouseEvent e) {
                                    btn7.setBackground(new Color(27, 27, 132));
                                }

                                @Override
                                public void mouseExited(MouseEvent e) {
                                    btn7.setBackground(new Color(11, 11, 46));
                                }
                            });


                            btn7.addActionListener(new ActionListener() {
                                @Override
                                public void actionPerformed(ActionEvent e) {

                                    panel2.setVisible(true);
                                    panel3.setVisible(true);
                                    panel2.add(panel3);
                                    panel2.setBounds(201, 1, 900, 700);
                                    panel2.setBackground(Color.white);//frame2 center panel(faculty)
                                    lbldash.setText("Faculty");
                                    addfac.setVisible(true);
                                    addstu.setVisible(false);
                                    addsub.setVisible(false);
                                    f1.add(panel2);
                                    panel2.setLayout(null);
                                    panel1.setVisible(false);//frame2 center panel(dashboard)
                                    panel4.setVisible(false);//frame2 center panel(students)
                                    panel5.setVisible(false);//frame2 center panel(subjects)
                                    panel6.setVisible(false);//frame2 center panel(attendance)
                                    panel3.add(cb);
                                    cb.setBackground(Color.white);
                                    cb.setVisible(false);
                                    cb1.setVisible(false);
                                    cb2.setVisible(false);

                                    //////////for table///////////
                                    JTable table = new JTable();
                                    DefaultTableModel model = new DefaultTableModel();
                                    String[] columns = {"Faculty ID", "Faculty Name", "Email ID", "Semester", "Experience"};
                                    table.setBounds(10, 300, 400, 400);
                                    model.setColumnIdentifiers(columns);
                                    // panel2.add(table);


                                    table.setModel(model);
                                    table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
                                    table.setFillsViewportHeight(true);
                                    JTableHeader header = table.getTableHeader();
                                    header.setBorder(border);
                                    header.setBackground(new Color(164, 46, 190));
                                    header.setForeground(Color.white);
                                    JScrollPane scroll = new JScrollPane(table);
                                    scroll.setBounds(50, 170, 800, 500);
                                    scroll.setHorizontalScrollBarPolicy(
                                            JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
                                    scroll.setVerticalScrollBarPolicy(
                                            JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

                                    //////////for connecting database faculty////////////
                                    final String[] facid = {""};
                                    final String[] facname = {""};
                                    final String[] facemail = {""};
                                    final String[] facsem = {""};
                                    final String[] facex = {""};

                                    try {
                                        Class.forName("com.mysql.jdbc.Driver");
                                        //  System.out.println("OK");
                                        Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/department", "root", "");
                                        Statement stm = connect.createStatement();
                                        ResultSet rs = stm.executeQuery("SELECT * FROM faculty");

                                        while (rs.next()) {
                                            facid[0] = rs.getString("Faculty ID");
                                            facname[0] = rs.getString("Faculty Name");
                                            facemail[0] = rs.getString("Email ID");
                                            facsem[0] = rs.getString("Semester");
                                            facex[0] = rs.getString("Experience");

                                            model.addRow(new Object[]{facid[0], facname[0], facemail[0], facsem[0], facex[0]});
                                        }
                                    } catch (Exception i) {
                                        JOptionPane.showMessageDialog(null, i.getMessage(), "error", JOptionPane.ERROR_MESSAGE);
                                    }

                                    addfac.setFont(new Font("Arial", Font.BOLD, 17));
                                    addfac.setBounds(610, 100, 150, 30);
                                    addfac.setBackground(new Color(164, 46, 190));
                                    addfac.setForeground(Color.white);
                                    addfac.setBorder(border);
                                    addfac.addActionListener(new ActionListener() {
                                        @Override
                                        public void actionPerformed(ActionEvent e) {
                                            JFrame f2 = new JFrame("Add Faculty");
                                            f2.setSize(600, 600);
                                            f2.setLayout(null);
                                            f2.setBackground(Color.PINK);
                                            JPanel pane = new JPanel();
                                            pane.setLayout(null);
                                            f2.add(pane);
                                            pane.setBackground(Color.white);
                                            pane.setSize(600, 600);
                                            JLabel facad = new JLabel("~~Add Faculty~~");
                                            facad.setForeground(new Color(11, 11, 96));
                                            facad.setBounds(155, 10, 300, 80);
                                            facad.setFont(new Font("Arial", Font.BOLD, 28));
                                            pane.add(facad);
                                            JLabel lblfacid = new JLabel("Faculty ID");
                                            lblfacid.setFont(new Font("Arial", Font.BOLD, 18));
                                            lblfacid.setForeground(Color.black);
                                            lblfacid.setBounds(80, 90, 120, 50);
                                            pane.add(lblfacid);
                                            JTextField tfacid = new JTextField(15);
                                            tfacid.setBounds(220, 100, 180, 30);
                                            pane.add(tfacid);
                                            //String tfac1=tfac.getText();
                                            JLabel lblfac = new JLabel("Faculty Name");
                                            lblfac.setFont(new Font("Arial", Font.BOLD, 18));
                                            lblfac.setBounds(80, 140, 120, 50);
                                            lblfac.setForeground(Color.black);
                                            pane.add(lblfac);
                                            JTextField tfac = new JTextField(15);
                                            tfac.setBounds(220, 150, 180, 30);
                                            pane.add(tfac);
                                            //   String tfacid1=tfac.getText();
                                            JLabel lblfacem = new JLabel("Email ID");
                                            lblfacem.setFont(new Font("Arial", Font.BOLD, 18));
                                            lblfacem.setForeground(Color.black);
                                            lblfacem.setBounds(80, 190, 120, 50);
                                            pane.add(lblfacem);
                                            JTextField tfacem = new JTextField(15);
                                            tfacem.setBounds(220, 200, 180, 30);
                                            pane.add(tfacem);
                                            String tfacem1 = tfacem.getText();
                                            JLabel lblfacsem = new JLabel("Semester");
                                            lblfacsem.setFont(new Font("Arial", Font.BOLD, 18));
                                            lblfacsem.setForeground(Color.black);
                                            lblfacsem.setBounds(80, 240, 120, 50);
                                            pane.add(lblfacsem);
                                            JTextField tfacsem = new JTextField(15);
                                            tfacsem.setBounds(220, 250, 180, 30);
                                            pane.add(tfacsem);
                                            //String tfacex1=tfacex.getText();
                                            JLabel lblfacex = new JLabel("Experience");
                                            lblfacex.setFont(new Font("Arial", Font.BOLD, 18));
                                            lblfacex.setForeground(Color.black);
                                            lblfacex.setBounds(80, 290, 120, 50);
                                            pane.add(lblfacex);
                                            JTextField tfacex = new JTextField(15);
                                            tfacex.setBounds(220, 300, 180, 30);
                                            pane.add(tfacex);
                                            // String tfacsem1=tfacsem.getText();
                                            JButton adding = new JButton("Add");
                                            adding.setBackground(new Color(11, 11, 96));
                                            adding.setForeground(Color.white);
                                            adding.setBounds(200, 380, 150, 40);
                                            pane.add(adding);

                                            adding.addActionListener(new ActionListener() {
                                                @Override
                                                public void actionPerformed(ActionEvent e) {
                                                    if (tfac.getText().length() == 0 || tfacid.getText().length() == 0 || tfacem.getText().length() == 0 || tfacex.getText().length() == 0 || tfacsem.getText().length() == 0)
                                                        JOptionPane.showMessageDialog(null, "please fill the blank spaces !");
                                                    else {
                                                        try {
                                                            Class.forName("com.mysql.jdbc.Driver");
                                                            System.out.println("OK");
                                                            Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/department", "root", "");
                                                            ////
                                                            String query = "INSERT INTO faculty " + "VALUES (?,?,?,?,?)";
                                                            PreparedStatement statmnt = connect.prepareStatement(query);
                                                            statmnt.setString(1, tfacid.getText());
                                                            statmnt.setString(2, tfac.getText());
                                                            statmnt.setString(3, tfacem.getText());
                                                            statmnt.setString(4, tfacsem.getText());
                                                            statmnt.setString(5, tfacex.getText());
                                                            statmnt.execute();

                                                            JOptionPane.showMessageDialog(null, "record added successfully!");
                                                            String tfacid1 = tfacid.getText();
                                                            String tfac1 = tfac.getText();
                                                            String tfacem1 = tfacem.getText();
                                                            String tfacsem1 = tfacsem.getText();
                                                            String tfacex1 = tfacex.getText();
                                                            Statement stm = connect.createStatement();
                                                            ResultSet rs = stm.executeQuery("SELECT * FROM faculty");
                                                            model.addRow(new Object[]{tfacid1, tfac1, tfacem1, tfacsem1, tfacex1});
                                                        }///try
                                                        catch (Exception i) {
                                                            JOptionPane.showMessageDialog(null, i.getMessage(), "error", JOptionPane.ERROR_MESSAGE);
                                                        }
                                                    }

                                                }
                                            });//add button action listener
                                            f2.setVisible(true);
                                        }
                                    });
                                    panel3.add(addfac);
                                    panel2.add(scroll);
                                    f1.add(panel2);
                                    f1.setLayout(null);
                                }
                            });

                            ////////////////////////////////////////////STUDENTS//////////////////////////////////////////////////
                            JButton btn8 = new JButton("Students    ");
                            btn8.setFont(new Font("Arial", Font.BOLD, 20));
                            btn8.setForeground(Color.white);
                            btn8.setBackground(new Color(11, 11, 46));
                            btn8.setBounds(1, 340, 250, 50);
                            btn8.setBorderPainted(false);
                            panel.add(btn8);
                            btn8.addMouseListener(new MouseListener() {
                                @Override
                                public void mouseClicked(MouseEvent e) {
                                }

                                @Override
                                public void mousePressed(MouseEvent e) {
                                }

                                @Override
                                public void mouseReleased(MouseEvent e) {
                                }

                                @Override
                                public void mouseEntered(MouseEvent e) {
                                    btn8.setBackground(new Color(27, 27, 132));
                                }

                                @Override
                                public void mouseExited(MouseEvent e) {
                                    btn8.setBackground(new Color(11, 11, 46));
                                }
                            });
                            btn8.addActionListener(new ActionListener() {
                                @Override
                                public void actionPerformed(ActionEvent e) {

                                    panel4.setVisible(true);
                                    panel3.setVisible(true);
                                    panel3.add(cb1);
                                    cb1.setBackground(Color.white);
                                    panel4.add(panel3);
                                    panel4.setBounds(201, 1, 900, 700);
                                    panel4.setBackground(Color.white);//frame2 center panel(faculty)
                                    lbldash.setText("Students");
                                    f1.add(panel4);
                                    panel4.setLayout(null);
                                    panel1.setVisible(false);//frame2 center panel(dashboard)
                                    panel2.setVisible(false);//frame2 center panel(faculty)
                                    panel5.setVisible(false);//frame2 center panel(subjects)
                                    panel6.setVisible(false);//frame2 center panel(attendance)

                                    cb1.setVisible(false);
                                    cb.setVisible(false);
                                    cb2.setVisible(false);
                                    //////////for table///////////
                                    JTable tablestu = new JTable();
                                    DefaultTableModel modelstu = new DefaultTableModel();
                                    String[] columns2 = {"Roll NO", "Student Name", "Email ID", "Section", "Sem/Year"};
                                    tablestu.setBounds(10, 300, 400, 400);
                                    modelstu.setColumnIdentifiers(columns2);
                                    // panel2.add(table);
                                    tablestu.setModel(modelstu);
                                    tablestu.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
                                    tablestu.setFillsViewportHeight(true);
                                    JTableHeader headerstu = tablestu.getTableHeader();
                                    headerstu.setBorder(border);
                                    headerstu.setBackground(new Color(240, 156, 40));
                                    headerstu.setForeground(Color.white);
                                    JScrollPane scrollstu = new JScrollPane(tablestu);
                                    scrollstu.setBounds(50, 170, 800, 500);
                                    scrollstu.setHorizontalScrollBarPolicy(
                                            JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
                                    scrollstu.setVerticalScrollBarPolicy(
                                            JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

                                    //////////for connecting database////////////
                                    final String[] sturoll = {""};
                                    final String[] stuname = {""};
                                    final String[] stuemail = {""};
                                    final String[] stusec = {""};
                                    final String[] stusem = {""};

                                    try {
                                        Class.forName("com.mysql.jdbc.Driver");
                                        //  System.out.println("OK");
                                        Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/department", "root", "");
                                        Statement stmstu = connect.createStatement();
                                        ResultSet rsstu = stmstu.executeQuery("SELECT * FROM Student");

                                        while (rsstu.next()) {
                                            sturoll[0] = rsstu.getString("Roll no");
                                            stuname[0] = rsstu.getString("Student Name");
                                            stuemail[0] = rsstu.getString("Email ID");
                                            stusec[0] = rsstu.getString("Section");
                                            stusem[0] = rsstu.getString("Sem/Year");

                                            modelstu.addRow(new Object[]{sturoll[0], stuname[0], stuemail[0], stusec[0], stusem[0]});
                                        }
                                    } catch (Exception i) {
                                        JOptionPane.showMessageDialog(null, i.getMessage(), "error", JOptionPane.ERROR_MESSAGE);
                                    }
                                    addfac.setVisible(false);
                                    addsub.setVisible(false);


                                    addstu.setFont(new Font("Arial", Font.BOLD, 17));
                                    addstu.setBounds(610, 100, 150, 30);
                                    addstu.setBackground(new Color(240, 156, 40));
                                    addstu.setVisible(true);

                                    addstu.setForeground(Color.white);
                                    addstu.setBorder(border);
                                    addstu.addActionListener(new ActionListener() {
                                        @Override
                                        public void actionPerformed(ActionEvent e) {
                                            JFrame f3 = new JFrame("Add Student");
                                            f3.setSize(600, 600);
                                            f3.setLayout(null);
                                            // f3.setBackground(Color.PINK);

                                            JPanel panestu = new JPanel(); //student center panel
                                            panestu.setLayout(null);
                                            f3.add(panestu);
                                            panestu.setBackground(Color.white);
                                            panestu.setSize(600, 600);
                                            JLabel stuad = new JLabel("~~Add Student~~"); // student heading
                                            stuad.setForeground(new Color(11, 11, 96));
                                            stuad.setBounds(155, 10, 300, 80);
                                            stuad.setFont(new Font("Arial", Font.BOLD, 28));
                                            panestu.add(stuad);
                                            JLabel lblsturoll = new JLabel("Student Roll"); //student rollno label
                                            lblsturoll.setFont(new Font("Arial", Font.BOLD, 18));
                                            lblsturoll.setForeground(Color.black);
                                            lblsturoll.setBounds(80, 90, 120, 50);
                                            panestu.add(lblsturoll);
                                            JTextField tsturoll = new JTextField(15); //student rollno text
                                            tsturoll.setBounds(220, 100, 180, 30);
                                            panestu.add(tsturoll);
                                            //String tfac1=tfac.getText();
                                            JLabel lblstuname = new JLabel("Student Name"); //student name label
                                            lblstuname.setFont(new Font("Arial", Font.BOLD, 18));
                                            lblstuname.setBounds(80, 140, 120, 50);
                                            lblstuname.setForeground(Color.black);
                                            panestu.add(lblstuname);
                                            JTextField tstuname = new JTextField(15);  //student name text
                                            tstuname.setBounds(220, 150, 180, 30);
                                            panestu.add(tstuname);
                                            //   String tfacid1=tfac.getText();
                                            JLabel lblstuem = new JLabel("Email ID");  //student email label
                                            lblstuem.setFont(new Font("Arial", Font.BOLD, 18));
                                            lblstuem.setForeground(Color.black);
                                            lblstuem.setBounds(80, 190, 120, 50);
                                            panestu.add(lblstuem);
                                            JTextField tstuem = new JTextField(15);  //student email text
                                            tstuem.setBounds(220, 200, 180, 30);
                                            panestu.add(tstuem);
                                            String tstuem1 = tstuem.getText();
                                            JLabel lblstusec = new JLabel("Section");  //student sec label
                                            lblstusec.setFont(new Font("Arial", Font.BOLD, 18));
                                            lblstusec.setForeground(Color.black);
                                            lblstusec.setBounds(80, 240, 120, 50);
                                            panestu.add(lblstusec);
                                            JTextField tstusec = new JTextField(15);  //student sec text
                                            tstusec.setBounds(220, 250, 180, 30);
                                            panestu.add(tstusec);
                                            //String tstuex1=tstuex.getText();
                                            JLabel lblstusem = new JLabel("Semester");  //student sem label
                                            lblstusem.setFont(new Font("Arial", Font.BOLD, 18));
                                            lblstusem.setForeground(Color.black);
                                            lblstusem.setBounds(80, 290, 120, 50);
                                            panestu.add(lblstusem);
                                            JTextField tstusem = new JTextField(15);  //student sem text
                                            tstusem.setBounds(220, 300, 180, 30);
                                            panestu.add(tstusem);
                                            String tstusem1 = tstusem.getText();
                                            JButton addingstu = new JButton("Add");
                                            addingstu.setBackground(new Color(11, 11, 96));
                                            addingstu.setForeground(Color.white);
                                            addingstu.setBounds(200, 380, 150, 40);
                                            panestu.add(addingstu);
                                            addingstu.addActionListener(new ActionListener() {
                                                @Override
                                                public void actionPerformed(ActionEvent e) {
                                                    if (tstuname.getText().length() == 0 || tsturoll.getText().length() == 0 || tstuem.getText().length() == 0 || tstusec.getText().length() == 0 || tstusem.getText().length() == 0)
                                                        JOptionPane.showMessageDialog(null, "please fill all the blank spaces !");
                                                    else {
                                                        try {

                                                            Class.forName("com.mysql.jdbc.Driver");
                                                            System.out.println("OK");
                                                            Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/department", "root", "");
                                                            ////
                                                            String query1 = "INSERT INTO Student " + "VALUES (?,?,?,?,?)";
                                                            PreparedStatement statmntstu = connect.prepareStatement(query1);
                                                            statmntstu.setString(1, tsturoll.getText());
                                                            statmntstu.setString(2, tstuname.getText());
                                                            statmntstu.setString(3, tstuem.getText());
                                                            statmntstu.setString(4, tstusec.getText());
                                                            statmntstu.setString(5, tstusem.getText());
                                                            statmntstu.execute();

                                                            JOptionPane.showMessageDialog(null, "record added successfully!");
                                                            String tsturoll1 = tsturoll.getText();
                                                            String tstuname1 = tstuname.getText();
                                                            String tstuem1 = tstuem.getText();
                                                            String tstusec1 = tstusec.getText();
                                                            String tstusem1 = tstusem.getText();

                                                            Statement stmstu = connect.createStatement();
                                                            ResultSet rsstu = stmstu.executeQuery("SELECT * FROM Student");

                                                            modelstu.addRow(new Object[]{tsturoll1, tstuname1, tstuem1, tstusec1, tstusem1});
                                                        }///try
                                                        catch (Exception i) {
                                                            JOptionPane.showMessageDialog(null, i.getMessage(), "error", JOptionPane.ERROR_MESSAGE);
                                                        }
                                                    }
                                                }
                                            });//add button action listener

                                            f3.setVisible(true);
                                        }
                                    });
                                    panel3.add(addstu);
                                    panel4.add(scrollstu);
                                    f1.add(panel4);
                                    f1.setLayout(null);


                                }
                            });

                            JButton btn9 = new JButton("Subjects    ");
                            btn9.setFont(new Font("Arial", Font.BOLD, 20));
                            btn9.setForeground(Color.white);
                            btn9.setBackground(new Color(11, 11, 46));
                            btn9.setBounds(1, 400, 250, 50);
                            btn9.setBorderPainted(false);
                            panel.add(btn9);
                            btn9.addMouseListener(new MouseListener() {
                                @Override
                                public void mouseClicked(MouseEvent e) {
                                }

                                @Override
                                public void mousePressed(MouseEvent e) {
                                }

                                @Override
                                public void mouseReleased(MouseEvent e) {
                                }

                                @Override
                                public void mouseEntered(MouseEvent e) {
                                    btn9.setBackground(new Color(27, 27, 132));
                                }

                                @Override
                                public void mouseExited(MouseEvent e) {
                                    btn9.setBackground(new Color(11, 11, 46));
                                }
                            });
                            btn9.addActionListener(new ActionListener() {
                                @Override
                                public void actionPerformed(ActionEvent e) {
                                    panel5.setVisible(true);
                                    panel3.setVisible(true);

                                    panel5.add(panel3);
                                    panel3.add(cb2);
                                    cb2.setBackground(Color.white);
                                    panel5.setBounds(201, 1, 900, 700);
                                    panel5.setBackground(Color.white);//frame2 center panel(faculty)
                                    lbldash.setText("Subjects");
                                    addsub.setVisible(true);
                                    addstu.setVisible(false);
                                    addfac.setVisible(false);
                                    f1.add(panel5);
                                    panel5.setLayout(null);
                                    panel1.setVisible(false);//frame2 center panel(dashboard)
                                    panel2.setVisible(false);//frame2 center panel(faculty)
                                    panel4.setVisible(false);//frame2 center panel(students)
                                    panel6.setVisible(false);

                                    cb2.setVisible(false);
                                    cb.setVisible(false);
                                    cb1.setVisible(false);

                                    //////////for table///////////
                                    JTable tablesub = new JTable();
                                    DefaultTableModel modelsub = new DefaultTableModel();
                                    String[] columns3 = {"Subject Code", "Subject Name", "Sem/Year", "Subject Type", "Theory Marks", "Practical Marks"};
                                    tablesub.setBounds(10, 300, 400, 400);
                                    modelsub.setColumnIdentifiers(columns3);
                                    // panel2.add(table);


                                    tablesub.setModel(modelsub);
                                    tablesub.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
                                    tablesub.setFillsViewportHeight(true);
                                    JTableHeader headersub = tablesub.getTableHeader();
                                    headersub.setBorder(border);
                                    headersub.setBackground(new Color(244, 76, 33));
                                    headersub.setForeground(Color.white);
                                    JScrollPane scrollsub = new JScrollPane(tablesub);
                                    scrollsub.setBounds(50, 170, 800, 500);
                                    scrollsub.setHorizontalScrollBarPolicy(
                                            JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
                                    scrollsub.setVerticalScrollBarPolicy(
                                            JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

                                    //////////for connecting database////////////
                                    final String[] subcode = {""};
                                    final String[] subname = {""};
                                    final String[] subsem = {""};
                                    final String[] subtype = {""};
                                    final String[] subtmarks = {""};
                                    final String[] subpmarks = {""};

                                    try {
                                        Class.forName("com.mysql.jdbc.Driver");
                                        //  System.out.println("OK");
                                        Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/department", "root", "");
                                        Statement stmsub = connect.createStatement();
                                        ResultSet rssub = stmsub.executeQuery("SELECT * FROM Subject");

                                        while (rssub.next()) {
                                            subcode[0] = rssub.getString("Subject Code");
                                            subname[0] = rssub.getString("Subject Name");
                                            subsem[0] = rssub.getString("Sem/Year");
                                            subtype[0] = rssub.getString("Subject Type");
                                            subtmarks[0] = rssub.getString("Theory Marks");
                                            subpmarks[0] = rssub.getString("Practical Marks");

                                            modelsub.addRow(new Object[]{subcode[0], subname[0], subsem[0], subtype[0], subtmarks[0], subpmarks[0]});
                                        }
                                    } catch (Exception i) {
                                        JOptionPane.showMessageDialog(null, i.getMessage(), "error", JOptionPane.ERROR_MESSAGE);
                                    }

                                    addsub.setFont(new Font("Arial", Font.BOLD, 17));
                                    addsub.setBounds(610, 100, 150, 30);
                                    addsub.setBackground(new Color(244, 76, 33));
                                    addsub.setForeground(Color.white);
                                    addsub.setBorder(border);
                                    addsub.addActionListener(new ActionListener() {
                                        @Override
                                        public void actionPerformed(ActionEvent e) {
                                            JFrame f4 = new JFrame("Add Subject");
                                            f4.setSize(600, 600);
                                            f4.setLayout(null);
                                            //  f4.setBackground(Color.PINK);
                                            JPanel panesub = new JPanel(); //subject center panel
                                            panesub.setLayout(null);
                                            f4.add(panesub);
                                            panesub.setBackground(Color.white);
                                            panesub.setSize(600, 600);
                                            JLabel subad = new JLabel("~~Add Subject~~"); // subject heading
                                            subad.setForeground(new Color(11, 11, 96));
                                            subad.setBounds(155, 10, 300, 80);
                                            subad.setFont(new Font("Arial", Font.BOLD, 28));
                                            panesub.add(subad);
                                            JLabel lblsubcode = new JLabel("Subject Code"); //subject Code label
                                            lblsubcode.setFont(new Font("Arial", Font.BOLD, 18));
                                            lblsubcode.setForeground(Color.black);
                                            lblsubcode.setBounds(80, 90, 120, 50);
                                            panesub.add(lblsubcode);
                                            JTextField tsubcode = new JTextField(15); //subject code text
                                            tsubcode.setBounds(220, 100, 180, 30);
                                            panesub.add(tsubcode);
                                            //String tfac1=tfac.getText();
                                            JLabel lblsubname = new JLabel("Subject Name"); //subject name label
                                            lblsubname.setFont(new Font("Arial", Font.BOLD, 18));
                                            lblsubname.setBounds(80, 140, 120, 50);
                                            lblsubname.setForeground(Color.black);
                                            panesub.add(lblsubname);
                                            JTextField tsubname = new JTextField(15);  //subject name text
                                            tsubname.setBounds(220, 150, 180, 30);
                                            panesub.add(tsubname);
                                            //   String tfacid1=tfac.getText();
                                            JLabel lblsubsem = new JLabel("Sem/Year");  //sem label
                                            lblsubsem.setFont(new Font("Arial", Font.BOLD, 18));
                                            lblsubsem.setForeground(Color.black);
                                            lblsubsem.setBounds(80, 190, 120, 50);
                                            panesub.add(lblsubsem);
                                            JTextField tsubsem = new JTextField(15);  //ssem text
                                            tsubsem.setBounds(220, 200, 180, 30);
                                            panesub.add(tsubsem);
                                            //String tstuem1 = tstuem.getText();
                                            JLabel lblsubtype = new JLabel("Sub Type");  //subject Type label
                                            lblsubtype.setFont(new Font("Arial", Font.BOLD, 18));
                                            lblsubtype.setForeground(Color.black);
                                            lblsubtype.setBounds(80, 240, 120, 50);
                                            panesub.add(lblsubtype);
                                            JTextField tsubtype = new JTextField(15);  //subject Type text
                                            tsubtype.setBounds(220, 250, 180, 30);
                                            panesub.add(tsubtype);
                                            //String tstuex1=tstuex.getText();
                                            JLabel lbltmarks = new JLabel("Theory Marks");  //Theory Marks label
                                            lbltmarks.setFont(new Font("Arial", Font.BOLD, 18));
                                            lbltmarks.setForeground(Color.black);
                                            lbltmarks.setBounds(78, 290, 120, 50);
                                            panesub.add(lbltmarks);
                                            JTextField ttmarks = new JTextField(15);  //Theory marks text
                                            ttmarks.setBounds(220, 300, 180, 30);
                                            panesub.add(ttmarks);
                                            // String tfacsem1=tfacsem.getText();
                                            JLabel lblpmarks = new JLabel("Practical Marks");  //Practical Marks label
                                            lblpmarks.setFont(new Font("Arial", Font.BOLD, 18));
                                            lblpmarks.setForeground(Color.black);
                                            lblpmarks.setBounds(78, 350, 120, 50);
                                            panesub.add(lblpmarks);
                                            JTextField tpmarks = new JTextField(15);  //Practical marks text
                                            tpmarks.setBounds(220, 351, 180, 30);
                                            panesub.add(tpmarks);
                                            JButton addingsub = new JButton("Add");
                                            addingsub.setBackground(new Color(11, 11, 96));
                                            addingsub.setForeground(Color.white);
                                            addingsub.setBounds(200, 400, 150, 40);
                                            panesub.add(addingsub);
                                            addingsub.addActionListener(new ActionListener() {
                                                @Override
                                                public void actionPerformed(ActionEvent e) {
                                                    if (tsubname.getText().length() == 0 || tsubcode.getText().length() == 0 || tsubsem.getText().length() == 0 || tsubtype.getText().length() == 0 || tpmarks.getText().length() == 0 || tpmarks.getText().length() == 0)
                                                        JOptionPane.showMessageDialog(null, "Please fill all the blank spaces !");
                                                    else {
                                                        try {
                                                            Class.forName("com.mysql.jdbc.Driver");
                                                            System.out.println("OK");
                                                            Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/department", "root", "");
                                                            ////
                                                            String query2 = "INSERT INTO Subject " + "VALUES (?,?,?,?,?,?)";
                                                            PreparedStatement statmntsub = connect.prepareStatement(query2);
                                                            statmntsub.setString(1, tsubcode.getText());
                                                            statmntsub.setString(2, tsubname.getText());
                                                            statmntsub.setString(3, tsubsem.getText());
                                                            statmntsub.setString(4, tsubtype.getText());
                                                            statmntsub.setString(5, ttmarks.getText());
                                                            statmntsub.setString(6, tpmarks.getText());
                                                            statmntsub.execute();

                                                            JOptionPane.showMessageDialog(null, "record added successfully!");
                                                            String tsubcode1 = tsubcode.getText();
                                                            String tsubname1 = tsubname.getText();
                                                            String tsubsem1 = tsubsem.getText();
                                                            String tsubtype1 = tsubtype.getText();
                                                            String ttmarks1 = ttmarks.getText();
                                                            String tpmarks1 = tpmarks.getText();

                                                            Statement stmsub = connect.createStatement();
                                                            ResultSet rssub = stmsub.executeQuery("SELECT * FROM Subject");

                                                            modelsub.addRow(new Object[]{tsubcode1, tsubname1, tsubsem1, tsubtype1, ttmarks1, tpmarks1});
                                                        }///try
                                                        catch (Exception i) {
                                                            JOptionPane.showMessageDialog(null, i.getMessage(), "error", JOptionPane.ERROR_MESSAGE);
                                                        }
                                                    }
                                                }
                                            });//add button action listener
                                            f4.setVisible(true);
                                        }
                                    });
                                    panel3.add(addsub);
                                    panel5.add(scrollsub);
                                    f1.add(panel5);
                                    f1.setLayout(null);


                                }
                            });

                            ///////////attendance///////////////

                            JButton btnatt = new JButton("Attendance  ");
                            btnatt.setFont(new Font("Arial", Font.BOLD, 20));
                            btnatt.setForeground(Color.white);
                            btnatt.setBackground(new Color(11, 11, 46));
                            btnatt.setBounds(5, 470, 250, 50);
                            btnatt.setBorderPainted(false);
                            panel.add(btnatt);
                            btnatt.addMouseListener(new MouseListener() {
                                @Override
                                public void mouseClicked(MouseEvent e) {
                                }

                                @Override
                                public void mousePressed(MouseEvent e) {
                                }

                                @Override
                                public void mouseReleased(MouseEvent e) {
                                }

                                @Override
                                public void mouseEntered(MouseEvent e) {
                                    btnatt.setBackground(new Color(27, 27, 132));
                                }

                                @Override
                                public void mouseExited(MouseEvent e) {
                                    btnatt.setBackground(new Color(11, 11, 46));
                                }
                            });
                            btnatt.addActionListener(new ActionListener() {
                                @Override
                                public void actionPerformed(ActionEvent e) {

                                    panel6.setLayout(null);
                                    panel3.setVisible(true);
                                    panel6.add(panel3);

                                    // cb2.setBackground(Color.white);
                                    panel6.setBounds(201, 1, 900, 700);
                                    panel6.setBackground(Color.white);
                                    lbldash.setText("Attendance");
                                    addsub.setVisible(false);
                                    addstu.setVisible(false);
                                    addfac.setVisible(false);
                                    f1.add(panel6);

                                    panel1.setVisible(false);//frame2 center panel(dashboard)
                                    panel2.setVisible(false);//frame2 center panel(faculty)
                                    panel4.setVisible(false);//frame2 center panel(students)
                                    panel5.setVisible(false);//frame2 center panel(subjects)
                                    cb2.setVisible(false);
                                    cb.setVisible(false);
                                    cb1.setVisible(false);
                                    panel6.setVisible(true);
                                    ///////////////////atendance 18//////////////////
                                    JLabel labl18 = new JLabel("Attendance for 18 Batch  ");
                                    labl18.setFont(new Font("Arial", Font.BOLD, 18));
                                    panel6.add(labl18);
                                    labl18.setBounds(80, 190, 290, 30);
                                    final String[] link18 = {"http://172.16.100.35/report_view_ug"};
                                    JButton btn18 = new JButton("Edit");
                                    btn18.setBounds(380, 195, 60, 30);
                                    btn18.setBorder(border);
                                    btn18.setForeground(Color.white);
                                    btn18.setBackground(new Color(11, 11, 46));
                                    panel6.add(btn18);
                                    btn18.addActionListener(new ActionListener() {
                                        @Override
                                        public void actionPerformed(ActionEvent e) {
                                            JFrame frameatt = new JFrame("Edit");
                                            frameatt.setSize(500, 500);
                                            frameatt.setLayout(null);
                                            JLabel edit181 = new JLabel("Change Label");
                                            edit181.setBounds(50, 100, 80, 30);
                                            frameatt.add(edit181);
                                            JTextField t181 = new JTextField(20);
                                            t181.setBounds(150, 100, 300, 20);
                                            frameatt.add(t181);
                                            //  labl18i =t18i1.getText();
                                            JLabel edit18 = new JLabel("Add link");
                                            edit18.setBounds(50, 170, 80, 30);
                                            frameatt.add(edit18);
                                            JTextField t18 = new JTextField(30);
                                            t18.setBounds(150, 170, 300, 30);
                                            frameatt.add(t18);
                                            JButton add18 = new JButton("ADD");
                                            add18.setBounds(200, 230, 100, 30);
                                            add18.setBackground(new Color(11, 11, 46));
                                            add18.setForeground(Color.white);
                                            frameatt.add(add18);
                                            frameatt.setVisible(true);
                                            add18.addActionListener(new ActionListener() {

                                                @Override
                                                public void actionPerformed(ActionEvent e) {
                                                    labl18.setText(t181.getText());
                                                    link18[0] = t18.getText();
                                                }
                                            });///action listener add18i
                                        }
                                    });///btn18 action listener

                                    JButton btn18open = new JButton("Open ");
                                    btn18open.setBounds(440, 195, 90, 30);
                                    btn18open.setBorder(border);
                                    btn18open.setForeground(Color.white);
                                    btn18open.setBackground(new Color(11, 11, 46));
                                    panel6.add(btn18open);
                                    btn18open.addActionListener(new ActionListener() {
                                        @Override
                                        public void actionPerformed(ActionEvent e) {
                                            Desktop desk = Desktop.getDesktop();
                                            try {
                                                desk.browse(new URI(link18[0]));
                                            } catch (IOException ex) {
                                                ex.printStackTrace();
                                            } catch (URISyntaxException uriSyntaxException) {
                                                uriSyntaxException.printStackTrace();
                                            }
                                        }
                                    });//btn18open

                                    ///////////////////atendance 19//////////////////
                                    JLabel labl19 = new JLabel("Attendance for 19 Batch ");
                                    labl19.setFont(new Font("Arial", Font.BOLD, 18));
                                    panel6.add(labl19);
                                    labl19.setBounds(80, 280, 290, 30);
                                    final String[] link19 = {"http://172.16.100.35/report_view_ug"};
                                    JButton btn19 = new JButton("Edit");
                                    btn19.setBounds(380, 280, 60, 30);
                                    btn19.setBorder(border);
                                    btn19.setForeground(Color.white);
                                    btn19.setBackground(new Color(11, 11, 46));
                                    panel6.add(btn19);
                                    btn19.addActionListener(new ActionListener() {
                                        @Override
                                        public void actionPerformed(ActionEvent e) {
                                            JFrame frameatt1 = new JFrame("Edit");
                                            frameatt1.setSize(500, 500);
                                            frameatt1.setLayout(null);
                                            JLabel edit191 = new JLabel("Change Label");
                                            edit191.setBounds(50, 100, 80, 30);
                                            frameatt1.add(edit191);
                                            JTextField t191 = new JTextField(20);
                                            t191.setBounds(150, 100, 300, 20);
                                            frameatt1.add(t191);
                                            //  labl18i =t18i1.getText();
                                            JLabel edit19 = new JLabel("Add link");
                                            edit19.setBounds(50, 170, 80, 30);
                                            frameatt1.add(edit19);
                                            JTextField t19 = new JTextField(30);
                                            t19.setBounds(150, 170, 300, 30);
                                            frameatt1.add(t19);
                                            JButton add19 = new JButton("ADD");
                                            add19.setBounds(200, 280, 100, 30);
                                            add19.setBackground(new Color(11, 11, 46));
                                            add19.setForeground(Color.white);
                                            frameatt1.add(add19);
                                            frameatt1.setVisible(true);
                                            add19.addActionListener(new ActionListener() {

                                                @Override
                                                public void actionPerformed(ActionEvent e) {
                                                    labl19.setText(t191.getText());
                                                    link19[0] = t19.getText();
                                                }
                                            });///action listener add18ii
                                        }
                                    });///btn19 action listener

                                    JButton btn19open = new JButton("Open ");
                                    btn19open.setBounds(440, 280, 90, 30);
                                    btn19open.setBorder(border);
                                    btn19open.setForeground(Color.white);
                                    btn19open.setBackground(new Color(11, 11, 46));
                                    panel6.add(btn19open);
                                    btn19open.addActionListener(new ActionListener() {
                                        @Override
                                        public void actionPerformed(ActionEvent e) {
                                            Desktop desk = Desktop.getDesktop();
                                            try {
                                                desk.browse(new URI(link19[0]));
                                            } catch (IOException ex) {
                                                ex.printStackTrace();
                                            } catch (URISyntaxException uriSyntaxException) {
                                                uriSyntaxException.printStackTrace();
                                            }
                                        }
                                    });//btn19open
                                    ///////////////////atendance 20//////////////////
                                    JLabel labl20 = new JLabel("Attendance for 20 Batch ");
                                    labl20.setFont(new Font("Arial", Font.BOLD, 18));
                                    panel6.add(labl20);
                                    labl20.setBounds(80, 340, 290, 30);
                                    final String[] link20 = {"http://172.16.100.35/report_view_ug"};
                                    JButton btn20 = new JButton("Edit");
                                    btn20.setBounds(380, 340, 60, 30);
                                    btn20.setBorder(border);
                                    btn20.setForeground(Color.white);
                                    btn20.setBackground(new Color(11, 11, 46));
                                    panel6.add(btn20);
                                    btn20.addActionListener(new ActionListener() {
                                        @Override
                                        public void actionPerformed(ActionEvent e) {
                                            JFrame frameatt2 = new JFrame("Edit");
                                            frameatt2.setSize(500, 500);
                                            frameatt2.setLayout(null);
                                            JLabel edit201 = new JLabel("Change Label");
                                            edit201.setBounds(50, 100, 80, 30);
                                            frameatt2.add(edit201);
                                            JTextField t201 = new JTextField(20);
                                            t201.setBounds(150, 100, 300, 20);
                                            frameatt2.add(t201);
                                            //  labl18i =t18i1.getText();
                                            JLabel edit20 = new JLabel("Add link");
                                            edit20.setBounds(50, 170, 80, 30);
                                            frameatt2.add(edit20);
                                            JTextField t20 = new JTextField(30);
                                            t20.setBounds(150, 170, 300, 30);
                                            frameatt2.add(t20);
                                            JButton add20 = new JButton("ADD");
                                            add20.setBounds(200, 230, 100, 30);
                                            add20.setBackground(new Color(11, 11, 46));
                                            add20.setForeground(Color.white);
                                            frameatt2.add(add20);
                                            frameatt2.setVisible(true);
                                            add20.addActionListener(new ActionListener() {

                                                @Override
                                                public void actionPerformed(ActionEvent e) {
                                                    labl20.setText(t201.getText());
                                                    link20[0] = t20.getText();
                                                }
                                            });///action listener add18ii
                                        }
                                    });///btn20 action listener

                                    JButton btn20open = new JButton("Open ");
                                    btn20open.setBounds(440, 340, 90, 30);
                                    btn20open.setBorder(border);
                                    btn20open.setForeground(Color.white);
                                    btn20open.setBackground(new Color(11, 11, 46));
                                    panel6.add(btn20open);
                                    btn20open.addActionListener(new ActionListener() {
                                        @Override
                                        public void actionPerformed(ActionEvent e) {
                                            Desktop desk = Desktop.getDesktop();
                                            try {
                                                desk.browse(new URI(link20[0]));
                                            } catch (IOException ex) {
                                                ex.printStackTrace();
                                            } catch (URISyntaxException uriSyntaxException) {
                                                uriSyntaxException.printStackTrace();
                                            }
                                        }
                                    });//btn20open
                                }
                            });//btnatt action listener

                            ///////////Back to frame1///////////////

                            JButton btnlogout = new JButton("   LOGOUT    ");
                            btnlogout.setFont(new Font("Arial", Font.BOLD, 20));
                            btnlogout.setForeground(Color.white);
                            btnlogout.setBackground(new Color(11, 11, 46));//
                            btnlogout.setBackground(Color.RED);
                            btnlogout.setBounds(60, 550, 140, 30);
                            // btnlogout.setBorderPainted(false);
                            btnlogout.setBorder(border);
                            panel.add(btnlogout);

                            btnlogout.addMouseListener(new MouseListener() {
                                @Override
                                public void mouseClicked(MouseEvent e) {
                                }

                                @Override
                                public void mousePressed(MouseEvent e) {
                                }

                                @Override
                                public void mouseReleased(MouseEvent e) {
                                }

                                @Override
                                public void mouseEntered(MouseEvent e) {
                                    btnlogout.setBackground(new Color(27, 27, 132));
                                }

                                @Override
                                public void mouseExited(MouseEvent e) {
                                    btnlogout.setBackground(Color.RED);
                                }
                            });
                            btnlogout.addActionListener(new ActionListener() {
                                @Override
                                public void actionPerformed(ActionEvent e) {
                                    f.setVisible(true);
                                    f1.setVisible(false);
                                    btn3.setVisible(true);
                                    btn4.setVisible(true);
                                    p3.setVisible(false);

                                    btn3.addActionListener(new ActionListener() {
                                        @Override
                                        public void actionPerformed(ActionEvent e) {
                                            p3.setVisible(true);
                                            btn3.setVisible(false);
                                            btn4.setVisible(false);
                                            btn5.addActionListener(new ActionListener() {
                                                @Override
                                                public void actionPerformed(ActionEvent e) {
                                                    f.setVisible(false);
                                                    f1.setVisible(false);
                                                    // new stuLogin();

                                                }
                                            });
                                        }
                                    });
                                    btn4.addActionListener(new ActionListener() {
                                        @Override
                                        public void actionPerformed(ActionEvent e) {
                                            p3.setVisible(true);
                                            btn3.setVisible(false);
                                            btn4.setVisible(false);
                                            ///////login panel//////////
                                            btn3.setVisible(false);
                                            btn4.setVisible(false);
                                            p3.setVisible(true);
                                            lbl2.add(p3);
                                            //  p3.setBackground(new Color(110,80,110,190));
                                            p3.setBackground(new Color(11, 11, 46, 230));
                                            p3.setBounds(240, 140, 300, 350);
                                            p3.setBorder(border);
                                            p3.setLayout(null);

                                            ImageIcon imag = new ImageIcon("C:\\Users\\Zukhrufa\\IdeaProjects\\untitled\\src\\com\\company\\user3.png");
                                            JLabel imaglbl = new JLabel(imag);
                                            imaglbl.setBounds(100, 10, 100, 150);
                                            p3.add(imaglbl);
                                            Border border1 = BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(70, 50, 95));//for line textbox


                                            JTextField name1 = new JTextField("Student");  ///acc name :student
                                            name1.setBounds(70, 170, 170, 25);
                                            name1.setBorder(border1);
                                            name1.setVisible(true);

                                            p3.add(name1);
                                            JPasswordField pass1 = new JPasswordField("20sw031");//pass is 20sw031
                                            pass1.setBounds(70, 220, 170, 25);
                                            pass1.setBorder(border1);
                                            p3.add(pass1);


                                            btn51.setForeground(Color.white);
                                            btn51.setBorder(border);
                                            btn51.setBounds(90, 280, 130, 30);
                                            btn51.setBackground(new Color(27, 27, 132));
                                            btn5.setVisible(false);
                                            p3.add(btn51);
                                            btn51.addActionListener(new ActionListener() {
                                                @Override
                                                public void actionPerformed(ActionEvent e) {

                                                    String name1value = name1.getText();
                                                    String pass1value = pass1.getText();

                                                    f1.setVisible(false);
                                                    f.setVisible(false);

                                                }
                                            });


                                        }
                                    });
                                }
                            });


                            panel1.add(panel3);
                            JLabel lbladmin = new JLabel("Welcome Administrator!");
                            lbladmin.setBounds(500, 1, 450, 80);
                            lbladmin.setFont(new Font("Arial", Font.BOLD, 24));
                            lbladmin.setForeground(Color.white);
                            panel3.add(lbladmin);


                    /*    }
                           else
                               JOptionPane.showMessageDialog(f1,"INVALID ID OR PASSWORD!");*/
                        } }});} });

        btn4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {


                ///////login panel//////////
                btn3.setVisible(false);
                btn4.setVisible(false);
                p3.setVisible(true);
                lbl2.add(p3);
                //  p3.setBackground(new Color(110,80,110,190));
                p3.setBackground(new Color(11,11,46,230));
                p3.setBounds(240,140,300,350);
                p3.setBorder(border);
                p3.setLayout(null);

                ImageIcon imag=new ImageIcon("C:\\Users\\Zukhrufa\\IdeaProjects\\untitled\\src\\com\\company\\user3.png");
                JLabel imaglbl=new JLabel(imag);
                imaglbl.setBounds(100,10,100,150);
                p3.add(imaglbl);
                Border border1=BorderFactory.createMatteBorder(0,0,1,0,new Color(70,50,95));//for line textbox
                        /*   JTextField name =new JTextField(" Admin ID....");
                           name.setBounds(70,170,170,25);
                           name.setBorder(border1);*/
                // name.setVisible(false);

                JTextField name1=new JTextField("student");
                name1.setBounds(70,170,170,25);
                name1.setBorder(border1);
                name1.setVisible(true);

                p3.add(name1);
                JPasswordField pass1=new JPasswordField("20sw031");
                pass1.setBounds(70,220,170,25);
                pass1.setBorder(border1);
                p3.add(pass1);


                btn51.setForeground(Color.white);
                btn51.setBorder(border);
                btn51.setBounds(90,280,130,30);
                btn51.setBackground(new Color(27,27,132));
                p3.add( btn51);
                btn51.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        f1.setVisible(false);
                        String name1value=name1.getText();
                        String pass1value=pass1.getText();
                        //  if (name1value.equals("student")&&pass1value.equals("20sw031")) {
                        f1.setVisible(false);
                        f.setVisible(false);
                        new stuLogin();
                        //  }
                    }
                }); }});



        p.add(lbl);
        p.add(btn);
        p.add(btn1);
        p.add(btn2);
        lbl2.add(btn3);
        lbl2.add(btn4);
        f.add(p);
        f.add(p1);
        f.setLayout(new BorderLayout());
        f.setVisible(true);
        f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);


    }
    public static void main(String[] args) {
        new DepartmentManagement();
    }
}
