package  com.company;
import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;

import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class GpaCalculator {
    JFrame f=new JFrame("Calculate GPA");
    JTextField t1=new JTextField(15);
    JTextField ch1=new JTextField(15);
    JTextField t2=new JTextField(15);
    JTextField ch2=new JTextField(15);
    JTextField t3=new JTextField(15);
    JTextField ch3=new JTextField(15);
    JTextField t4=new JTextField(15);
    JTextField ch4=new JTextField(15);
    JTextField t5=new JTextField(15);
    JTextField ch5=new JTextField(15);
    JTextField t6=new JTextField(15);
    JTextField ch6=new JTextField(15);
    JTextField t7=new JTextField(15);
    JTextField t8=new JTextField(30);//for gpa
    JTextField t9=new JTextField(30);//for tcredit
    JLabel l1= new JLabel("SUB1+C.H");
    JLabel l2= new JLabel("SUB2+C.H");
    JLabel l3= new JLabel("SUB3+C.H");
    JLabel l4= new JLabel("SUB4+C.H");
    JLabel l5= new JLabel("SUB5+C.H");
    JLabel l6= new JLabel("SUB6+C.H");
    JLabel l7= new JLabel("   GPA  ");
    JLabel l8= new JLabel("GPA Calculator");
    JLabel l9= new JLabel("Enter T.Credit Hours");

    GpaCalculator() {

        JPanel p=new JPanel();
        JPanel p2=new JPanel();
        Border border=BorderFactory.createRaisedBevelBorder();
        p.setBounds(1,1,800,700);
        p2.setBounds(220,30,500,600);
        p2.setBackground(new Color(0,0,0,60));
        p2.setBorder(border);
        p2.setLayout(null);
        JLabel lbl2=new JLabel(new ImageIcon("C:\\Users\\Zukhrufa\\IdeaProjects\\untitled\\src\\com\\company\\g1.jpg"));//background
        lbl2.setBounds(1,1,800,700);
        lbl2.add(p2);
        p.add(lbl2);
        l8.setBounds(200,5,200,70);
        l8.setForeground(Color.white);
        l8.setFont(new Font("Arial",Font.BOLD,20));
        p2.add(l8);
        l1.setBounds(20,70,200,70);
        l1.setForeground(Color.white);
        l1.setFont(new Font("Arial",Font.PLAIN,18));
        p2.add(l1);
        l2.setBounds(20,130,200,70);
        l2.setForeground(Color.white);
        l2.setFont(new Font("Arial",Font.PLAIN,18));
        p2.add(l2);
        t1.setBounds(135,90,80,25);
        p2.add(t1);
        ch1.setBounds(235,90,80,25);
        p2.add(ch1);
        t2.setBounds(135,150,80,25);
        p2.add(t2);
        ch2.setBounds(235,150,80,25);
        p2.add(ch2);
        t3.setBounds(135,210,80,25);
        p2.add(t3);
        ch3.setBounds(235,210,80,25);
        p2.add(ch3);
        t4.setBounds(135,270,80,25);
        p2.add(t4);
        ch4.setBounds(235,270,80,25);
        p2.add(ch4);
        t5.setBounds(135,320,80,25);
        p2.add(t5);
        ch5.setBounds(235,320,80,25);
        p2.add(ch5);
        t6.setBounds(135,380,80,25);
        p2.add(t6);
        ch6.setBounds(235,380,80,25);
        p2.add(ch6);
        t9.setBounds(205,430,80,25);
        p2.add(t9);
        t8.setBounds(205,480,80,25);
        p2.add(t8);
        l3.setBounds(20,190,200,70);
        l3.setForeground(Color.white);
        l3.setFont(new Font("Arial",Font.PLAIN,18));
        p2.add(l3);
        l4.setBounds(20,250,200,70);
        l4.setForeground(Color.white);
        l4.setFont(new Font("Arial",Font.PLAIN,18));
        p2.add(l4);
        l5.setBounds(20,300,200,70);
        l5.setForeground(Color.white);
        l5.setFont(new Font("Arial",Font.PLAIN,18));
        p2.add(l5);
        l6.setBounds(20,360,200,70);
        l6.setForeground(Color.white);
        l6.setFont(new Font("Arial",Font.PLAIN,18));
        p2.add(l6);
        l9.setBounds(20,410,200,70);
        l9.setForeground(Color.white);
        l9.setFont(new Font("Arial",Font.PLAIN,18));
        p2.add(l9);
        l7.setBounds(60,460,200,70);
        l7.setForeground(Color.white);
        l7.setFont(new Font("Arial",Font.PLAIN,18));
        p2.add(l7);
        JButton submit=new JButton("SUBMIT");
        JButton clear=new JButton("CLEAR");
        p2.add(submit);
        p2.add(clear);
        submit.setBounds(110, 540, 100, 30);
        clear.setBounds(250, 540, 100, 30);
        submit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String s1 = t1.getText();
                String s2 = t2.getText();
                String s3 = t3.getText();
                String s4 = t4.getText();
                String s5 = t5.getText();
                String s6 = t6.getText();
                String s8 = t8.getText();
                String s9 = t9.getText();
                String c1 = ch1.getText();
                String c2 = ch2.getText();
                String c3 = ch3.getText();
                String c4 = ch4.getText();
                String c5 = ch5.getText();
                String c6 = ch6.getText();

                float t1=Float.parseFloat(s1);
                float t2=Float.parseFloat(s2);
                float t3=Float.parseFloat(s3);
                float t4=Float.parseFloat(s4);      ////(((t1*ch1)*ch1)+((t2*ch2)*ch2)+((t3*ch3)*ch3)+((t4*ch4)*ch4)+((t5*ch5)*ch5)+((t6*ch6)*ch6)/t9)
                float t5=Float.parseFloat(s5);
                float t6=Float.parseFloat(s6);
                //float t8=Float.parseFloat(s8);
                float t9=Float.parseFloat(s9);
                float ch1=Float.parseFloat(c1);
                float ch2=Float.parseFloat(c2);
                float ch3=Float.parseFloat(c3);
                float ch4=Float.parseFloat(c4);
                float ch5=Float.parseFloat(c5);
                float ch6=Float.parseFloat(c6);

                Float gpa=(Float) ((t1*ch1)+(t2*ch2)+(t3*ch3)+(t4*ch4)+(t5*ch5)+(t6*ch6))/t9;
                t8.setText(gpa +"");

            }
        });
        clear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() == clear) {

                    t1.setText(null);
                    t2.setText(null);
                    t3.setText(null);
                    t4.setText(null);
                    t5.setText(null);
                    t6.setText(null);
                    t7.setText(null);
                    t8.setText(null);
                    t9.setText(null);
                    ch1.setText(null);
                    ch2.setText(null);
                    ch3.setText(null);
                    ch4.setText(null);
                    ch5.setText(null);
                    ch6.setText(null);

                } else {
                }
            }
        });


        f.add(p);
        f.setSize(700, 700);
        f.setVisible(true);
        f.setContentPane(null);
        f.setDefaultCloseOperation(EXIT_ON_CLOSE);
        f.setLocationRelativeTo(null);
        f.setResizable(false);
    }

    public static void main(String[] args) {
        new GpaCalculator();
    }
}