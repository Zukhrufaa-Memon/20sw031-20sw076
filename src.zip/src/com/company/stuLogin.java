
package com.company;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

public class stuLogin
{
    stuLogin()
    {

        JFrame F=new JFrame();
        F.setSize(1070,700);

        ImageIcon img=new ImageIcon("C:\\Users\\Zukhrufa\\IdeaProjects\\untitled\\src\\com\\company\\logo1.png");
        JLabel lbl=new JLabel(img);
        lbl.setBounds(12,30,200,130);
        Border border=BorderFactory.createRaisedBevelBorder();
        JPanel P=new JPanel();//side panel
        P.setBounds(1,1,250,700);///side panel frame1
        P.setLayout(null);
        JPanel P3=new JPanel();//faculty
        JPanel P4=new JPanel();//course
        JPanel P5=new JPanel();//attendence


        P.setBackground(new Color(11,11,46));
        JPanel P1=new JPanel();///center panel
        P1.setLayout(null);
        P1.setBounds(251,1,800,700);
        P1.setBackground(Color.white);
        JPanel P2=new JPanel();//header
        P2.setBounds(1,1,800,130);
        P2.setBackground(new Color(11,11,46,230));
        P2.setLayout(null);

        P4.setBounds(251,1,800,700);
        P5.setBounds(251,1,800,700);

        P3.setLayout(null);
        P4.setLayout(null);
        P5.setLayout(null);
        JLabel ladmin=new JLabel("Welcome To Student Login!!");
        ladmin.setBounds(350,0,450,80);
        ladmin.setFont(new Font("Arial",Font.BOLD,28));
        ladmin.setForeground(Color.white);
        P2.add(ladmin);
        JLabel ld=new JLabel("DASHBOARD");
        P2.add(ld);
        ld.setForeground(Color.white);
        ld.setBounds(70,60,450,80);
        ld.setFont(new Font("Arial",Font.BOLD,28));

        JButton Bt1=new JButton();
        Bt1.setBounds(100,230,150,180);
        Bt1.setIcon(new ImageIcon("C:\\Users\\Zukhrufa\\IdeaProjects\\untitled\\src\\com\\company\\facex2.png"));
        P1.add(Bt1);
        Bt1.setBorder(border);
        JButton Bt2=new JButton();
        Bt2.setBounds(340,230,150,180);
        Bt2.setIcon(new ImageIcon("C:\\Users\\Zukhrufa\\IdeaProjects\\untitled\\src\\com\\company\\bookex.png"));
        P1.add(Bt2);
        Bt2.setBorder(border);
        JButton Bt3=new JButton();
        Bt3.setBounds(560,230,150,180);
        Bt3.setIcon(new ImageIcon("C:\\Users\\Zukhrufa\\IdeaProjects\\untitled\\src\\com\\company\\attendance.png"));
        P1.add(Bt3);
        Bt3.setBorder(border);




        ////////////////////sidepanel buttons//////////////////
        JButton Btn=new JButton("Dashboard");
        Btn.setBounds(1,210,230,50);
        Btn.setFont(new Font("Arial",Font.BOLD,20));
        Btn.setForeground(Color.white);
        Btn.setBackground(new Color(11,11,46));

        Btn.setBorderPainted(false);
        Btn.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {}
            @Override
            public void mousePressed(MouseEvent e) {}
            @Override
            public void mouseReleased(MouseEvent e) {}
            @Override
            public void mouseEntered(MouseEvent e) {
                //btn.setBackground(new Color(116,66,200));}
                Btn.setBackground(new Color(27,27,132));}
            @Override
            public void mouseExited(MouseEvent e) {
                Btn.setBackground(new Color(11,11,46));}});

        Btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                JLabel ladmin=new JLabel("Welcome To Student Login!!");
                ladmin.setBounds(350,0,450,80);
                ladmin.setFont(new Font("Arial",Font.BOLD,23));
                ladmin.setForeground(Color.white);
                P2.add(ladmin);
                P3.setVisible(false);
                P4.setVisible(false);
                P5.setVisible(false);
                ld.setText("DASHBOARD");
                JLabel ld=new JLabel("DASHBOARD");
                P2.add(ld);
                ld.setForeground(Color.white);
                ld.setBounds(70,60,450,80);
                ld.setFont(new Font("Arial",Font.BOLD,28));

                JButton Bt1=new JButton();
                Bt1.setBounds(100,230,150,180);
                Bt1.setIcon(new ImageIcon("C:\\Users\\Zukhrufa\\IdeaProjects\\untitled\\src\\com\\company\\facex2.png"));
                P1.add(Bt1);
                Bt1.setBorder(border);
                JButton Bt2=new JButton();
                Bt2.setBounds(340,230,150,180);
                Bt2.setIcon(new ImageIcon("C:\\Users\\Zukhrufa\\IdeaProjects\\untitled\\src\\com\\company\\bookex.png"));
                P1.add(Bt2);
                Bt2.setBorder(border);
                JButton Bt3=new JButton();
                Bt3.setBounds(560,230,150,180);
                Bt3.setIcon(new ImageIcon("C:\\Users\\Zukhrufa\\IdeaProjects\\untitled\\src\\com\\company\\attendence.jpeg"));
                P1.add(Bt3);
                Bt2.setBorder(border);
                Bt3.setBorder(border);
                P1.add(P2);
                P3.setVisible(false);
                P4.setVisible(false);
                P5.setVisible(false);
            }
        });

        JButton Btn1=new JButton("Faculty     ");

        Btn1.setBounds(1,280,230,50);
        Btn1.setFont(new Font("Arial",Font.BOLD,22));
        Btn1.setForeground(Color.white);
        Btn1.setBackground(new Color(11,11,46));
        P3.add(P2);
        Btn1.setBorderPainted(false);
        Btn1.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {}
            @Override
            public void mousePressed(MouseEvent e) {}
            @Override
            public void mouseReleased(MouseEvent e) {}
            @Override
            public void mouseEntered(MouseEvent e) {
                //btn.setBackground(new Color(116,66,200));}
                Btn1.setBackground(new Color(27,27,132));}
            @Override
            public void mouseExited(MouseEvent e) {
                Btn1.setBackground(new Color(11,11,46));}});

        Btn1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {


                P3.setBounds(251,1,800,700);
                // P2.setBounds(1,1,800,130);
                P3.setVisible(true);
                P4.setVisible(false);
                P5.setVisible(false);
                Bt1.setVisible(false);
                Bt2.setVisible(false);
                Bt3.setVisible(false);
                ladmin.setVisible(false);
                ld.setText("FACULTY");


                ///database///
                JTable t1 = new JTable();
                DefaultTableModel m1 = new DefaultTableModel();
                String[] c1 = {"Faculty ID", "Faculty Name", "Email ID", "Semester", "Experience"};
                t1.setBounds(10, 300, 400, 400);
                m1.setColumnIdentifiers(c1);
                // panel2.add(table);

                t1.setBounds(10, 170, 800, 500);
                t1.setModel(m1);
                t1.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
                t1.setFillsViewportHeight(true);
                JTableHeader header = t1.getTableHeader();
                header.setBackground(new Color(11, 11, 46));
                header.setForeground(Color.white);
                JScrollPane sl = new JScrollPane(t1);

                sl.setHorizontalScrollBarPolicy(
                        JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
                sl.setVerticalScrollBarPolicy(
                        JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
                sl.setBounds(5, 170, 800, 500);

                //////////for connecting database////////////
                final String[] fid = {""};
                final String[] fname = {""};
                final String[] femail = {""};
                final String[] fsem = {""};
                final String[] fex = {""};

                try {
                    Class.forName("com.mysql.jdbc.Driver");
                    //  System.out.println("OK");
                    Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/department", "root", "");
                    Statement stm=connect.createStatement();
                    ResultSet Rs=stm.executeQuery("SELECT * FROM faculty");

                    while(Rs.next()) {
                        fid[0] = Rs.getString("Faculty ID");
                        fname[0] = Rs.getString("Faculty Name");
                        femail[0] = Rs.getString("Email ID");
                        fsem[0] = Rs.getString("Semester");
                        fex[0] = Rs.getString("Experience");

                        m1.addRow(new Object[]{fid[0], fname[0], femail[0], fsem[0], fex[0]});
                    }}
                catch (Exception i) {
                    JOptionPane.showMessageDialog(null,i.getMessage(),"error",JOptionPane.ERROR_MESSAGE);
                }

                P3.add(sl);



            }
        });


        JButton Btn2=new JButton("Courses    ");

        Btn2.setBounds(1,350,230,50);
        Btn2.setFont(new Font("Arial",Font.BOLD,22));
        Btn2.setForeground(Color.white);
        Btn2.setBackground(new Color(11,11,46));
        P2.add(P4);
        Btn2.setBorderPainted(false);
        Btn2.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {}
            @Override
            public void mousePressed(MouseEvent e) {}
            @Override
            public void mouseReleased(MouseEvent e) {}
            @Override
            public void mouseEntered(MouseEvent e) {
                //btn.setBackground(new Color(116,66,200));}
                Btn2.setBackground(new Color(27,27,132));}
            @Override
            public void mouseExited(MouseEvent e) {
                Btn2.setBackground(new Color(11,11,46));}});

        Btn2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {


                P4.setBounds(251,1,800,700);
                // P2.setBounds(1,1,800,130);
                P4.setVisible(true);
                P3.setVisible(false);
                P5.setVisible(false);
                Bt1.setVisible(false);
                Bt2.setVisible(false);
                Bt3.setVisible(false);
                ladmin.setVisible(false);
                ld.setText("COURSES");

                //////////for table///////////
                JTable tstu = new JTable();
                DefaultTableModel m2 = new DefaultTableModel();
                String[] cl2 = {"Roll NO", "Student Name", "Email ID", "Section", "Sem/Year"};
                tstu.setBounds(10, 300, 400, 400);
                m2.setColumnIdentifiers(cl2);
                // panel2.add(table);
                tstu.setModel(m2);
                tstu.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
                tstu.setFillsViewportHeight(true);
                JTableHeader hstu = tstu.getTableHeader();
                hstu.setBorder(border);
                hstu.setBackground(new Color(240,156,40));
                hstu.setForeground(Color.white);
                JScrollPane sstu = new JScrollPane(tstu);
                sstu.setBounds(5, 130, 800, 500);
                sstu.setHorizontalScrollBarPolicy(
                        JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
                sstu.setVerticalScrollBarPolicy(
                        JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

                //////////for connecting database////////////
                final String[] sroll = {""};
                final String[] sname = {""};
                final String[] semail = {""};
                final String[] ssec = {""};
                final String[] ssem = {""};

                try {
                    Class.forName("com.mysql.jdbc.Driver");
                    //  System.out.println("OK");
                    Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/department", "root", "");
                    Statement stmstu = connect.createStatement();
                    ResultSet Rsstu = stmstu.executeQuery("SELECT * FROM Student");

                    while (Rsstu.next()) {
                        sroll[0] = Rsstu.getString("Roll no");
                        sname[0] = Rsstu.getString("Student Name");
                        semail[0]=Rsstu.getString("Email ID");
                        ssec[0] = Rsstu.getString("Section");
                        ssem[0] = Rsstu.getString("Sem/Year");

                        m2.addRow(new Object[]{sroll[0], sname[0], semail[0], ssec[0], ssem[0]});
                    }
                } catch (Exception i) {
                    JOptionPane.showMessageDialog(null, i.getMessage(), "error", JOptionPane.ERROR_MESSAGE);
                }
                P4.add(sstu);
            }
        });

        JButton btnatt1=new JButton("Attendance ");
        btnatt1.setFont(new Font("Arial",Font.BOLD,22));
        btnatt1.setForeground(Color.white);
        btnatt1.setBackground(new Color(11,11,46));
        btnatt1.setBounds(1,415,230,50);
        btnatt1.setBorderPainted(false);
        P.add(btnatt1);
        btnatt1.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {}
            @Override
            public void mousePressed(MouseEvent e) {}
            @Override
            public void mouseReleased(MouseEvent e) {}
            @Override
            public void mouseEntered(MouseEvent e) {
                btnatt1.setBackground(new Color(27,27,132));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                btnatt1.setBackground(new Color(11,11,46));
            }
        });
        btnatt1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                JLabel labl20 = new JLabel("Attendance For All Batches");
                P5.add(labl20);
                labl20.setFont(new Font("Arial",Font.BOLD,18));

                labl20.setBounds(230,150,300,60);
                P5.setBounds(251,1,800,700);
                // P2.setBounds(1,1,800,130);
                P5.setVisible(true);
                P3.setVisible(false);
                P4.setVisible(false);
                Bt1.setVisible(false);
                Bt2.setVisible(false);
                Bt3.setVisible(false);
                ladmin.setVisible(false);

                ld.setText("Attendence");

                ///////////////attendance 20////////////
                P5.setLayout(null);

                JButton btn20open=new JButton("Open ");
                P5.add(btn20open);
                final String[] link20 = {"http://172.16.100.35/report_view_ug"};
                btn20open.setBounds(550,165,90,30);

                btn20open.setBorder(border);
                btn20open.setForeground(Color.white);
                btn20open.setBackground(new Color(11,11,46));

                btn20open.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        Desktop desk=Desktop.getDesktop();
                        try {
                            desk.browse(new URI(link20[0]));
                        } catch (IOException ex) {
                            ex.printStackTrace();
                        } catch (URISyntaxException uriSyntaxException) {
                            uriSyntaxException.printStackTrace();}
                    }});//btn20open

            }
        });
        JButton btngp1=new JButton("     GPA Calculator");
        btngp1.setFont(new Font("Arial",Font.BOLD,22));
        btngp1.setForeground(Color.white);
        btngp1.setBackground(new Color(11,11,46));
        btngp1.setBounds(1,475,230,50);
        btngp1.setBorderPainted(false);
        P.add(btngp1);
        btngp1.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {}
            @Override
            public void mousePressed(MouseEvent e) {}
            @Override
            public void mouseReleased(MouseEvent e) {}
            @Override
            public void mouseEntered(MouseEvent e) {
                btngp1.setBackground(new Color(27,27,132));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                btngp1.setBackground(new Color(11,11,46));
            }
        });
        btngp1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new GpaCalculator();
            }
        });

///////////Back to frame1///////////////

        JButton btnlogout=new JButton("   LOGOUT    ");
        btnlogout.setFont(new Font("Arial",Font.BOLD,20));
        btnlogout.setForeground(Color.white);
        btnlogout.setBackground(new Color(11,11,46));//
        btnlogout.setBackground(Color.RED);
        btnlogout.setBounds(60,590,140,30);
        // btnlogout.setBorderPainted(false);
        btnlogout.setBorder(border);
        P.add(btnlogout);
        btnlogout.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {}
            @Override
            public void mousePressed(MouseEvent e) {}
            @Override
            public void mouseReleased(MouseEvent e) {}
            @Override
            public void mouseEntered(MouseEvent e) {
                btnlogout.setBackground(new Color(27,27,132));}
            @Override
            public void mouseExited(MouseEvent e) {
                btnlogout.setBackground(Color.RED);}});
        btnlogout.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              /*  f.setVisible(true);
                btn3.setVisible(true);
                btn4.setVisible(true);
                p3.setVisible(false);
                f1.setVisible(false);
                btn3.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        p3.setVisible(true);
                        btn3.setVisible(false);
                        btn4.setVisible(false);*/
                F.setVisible(false);
                new com.company.DepartmentManagement();

            }
        });


        P.add(lbl);
        P.add(Btn);
        P.add(Btn1);
        P.add(Btn2);
        P1.add(P2);
        F.add(P1);
        F.add(P);
        F.add(P3);
        F.add(P4);
        F.add(P5);
        F.setLayout(null);
        F.setVisible(true);
        F.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);



    }




    public static void main(String[] args) {
        new stuLogin();
    }
}



